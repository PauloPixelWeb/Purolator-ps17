<?php
/**
 * 2010-2018 PixelWeb
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Software License Agreement that you can get at:
 * http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 *
 *  @author    PixelWeb <paulo@lievant.com>
 *  @copyright 2010-2018 Addons-Modules.com - Pixelweb.com.mx
 *  @license   http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 */

include_once(_PS_MODULE_DIR_ . 'purolator/classes/Enviopurolator.php');

class AdminPuroLatorController extends ModuleAdminControllerCore
{

    public function __construct()
    {
        
								
								$this->table = 'purolator_envio';
        $this->identifier = 'id_pedido';
        $this->className = 'EnvioPurolator';
        $this->lang = false;
        $this->context = Context::getContext();
        $this->list_no_link = true;
        $this->bootstrap = true;
        $this->allow_export = true;
								
								parent::__construct();

        $this->_select = '
            o.total_paid_tax_incl,
            o.id_currency,
            o.id_order AS id_pedido,
            a.id_purolator_envio AS id_pdf,
            o.date_add AS `fecha_pedido`,
            CONCAT(LEFT(c.`firstname`, 1), \'. \', c.`lastname`) AS `customer`';
        $this->_join = '
            RIGHT JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = a.`id_order`)
            INNER JOIN `' . _DB_PREFIX_ . 'customer` c ON (c.`id_customer` = o.`id_customer`)
            INNER JOIN `' . _DB_PREFIX_ . 'carrier` ca ON (o.`id_carrier` = ca.`id_carrier` AND ca.`external_module_name` = "purolator")';
        $this->_orderBy = 'o.id_order';
        $this->_orderWay = 'DESC';
								
					   $this->fields_list = array(
            'id_pedido' => array(
                'title' => $this->l('Order ID'),
                'align' => 'center',
                'width' => 70,
                'class' => 'fixed-width-xs'
            ),
            'customer' => array(
                'title' => $this->l('Customer'),
                'havingFilter' => true,
            ),
            'total_paid_tax_incl' => array(
                'title' => $this->l('Order Total'),
                'align' => 'center',
                'prefix' => '<b>',
                'suffix' => '</b>',
                'type' => 'price',
                'currency' => true
            ),
            'fecha_pedido' => array(
                'title' => $this->l('Order Date'),
                'width' => 152,
                'align' => 'right',
                'type' => 'datetime',
                'filter_key' => 'o!date_add'
            ),
            'date_add' => array(
                'title' => $this->l('Waybill Date'),
                'width' => 152,
                'align' => 'right',
                'type' => 'datetime',
                'filter_key' => 'a!date_add'
            ),
            'guia' => array(
                'title' => $this->l('Waybill Number'),
                'align' => 'center'
            ),
            'status' => array(
                'title' => $this->l('Shipment Status'),
                'align' => 'center'
            ),
            'id_pdf' => array(
                'title' => $this->l('Actions'),
                'width' => 35,
                'align' => 'center',
                'callback' => 'printPDFIcons',
                'orderby' => false,
                'search' => false,
                'remove_onclick' => true
										  )
        );
    }

    public function printPDFIcons($id_purolator, $tr)
    {
        $envio = new EnvioPurolator($id_purolator);
        if ($delivery_file = $envio->delivered_file)
        {
            $this->context->smarty->assign(array(
                'icon_title' => $this->l('Delivery Proof Image', null, null, false),
                'icon_href' => $this->context->shop->getBaseUrl() . '/modules/purolator/delivered/' . $delivery_file,
                'icon_icon' => 'image'
            ));
            return $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'purolator/views/templates/admin/icon.tpl');
        }
        elseif ($pdf = $envio->url)
        {
            $this->context->smarty->assign(array(
                'icon_title' => $this->l('Label PDF', null, null, false),
                'icon_href' => $pdf,
                'icon_icon' => 'print'
            ));
            return $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'purolator/views/templates/admin/icon.tpl');
        }
        else
            return '';
    }

    public function initToolbar()
    {
        parent::initToolbar();
        unset($this->toolbar_btn['new']);
    }

    public function renderKpis()
    {
        $kpis = array();

        $helper = new HelperKpi();
        $helper->id = 'box-generated-shipment-percent';
        $helper->icon = 'icon-bar-chart';
        $helper->color = 'color1';
        $helper->title = $this->l('Generated Percentage', null, null, false);
        $helper->subtitle = $this->l('ALL TIME', null, null, false);
        $valores = Db::getInstance()->getRow('SELECT COUNT(DISTINCT i.`id_order`) as cantidad, COUNT(DISTINCT o.`id_order`) as total
                                                FROM ' . _DB_PREFIX_ . 'purolator_envio i
                                                RIGHT JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = i.`id_order`)
                                                INNER JOIN `' . _DB_PREFIX_ . 'carrier` ca ON (o.`id_carrier` = ca.`id_carrier` AND ca.`external_module_name` = "purolator")');
        $helper->value = round($valores['cantidad'] / $valores['total'] * 100, 2) . '%';
        $kpis[] = $helper->generate();

        $helper = new HelperKpi();
        $helper->id = 'box-generated-shipment-total';
        $helper->icon = 'icon-truck';
        $helper->color = 'color2';
        $helper->title = $this->l('Generated Total', null, null, false);
        $helper->subtitle = $this->l('ALL TIME', null, null, false);
        $helper->value = $valores['cantidad'] . '/' . $valores['total'];
        $kpis[] = $helper->generate();

        $helper = new HelperKpiRow();
        $helper->kpis = $kpis;
        return $helper->generate();
    }

}
