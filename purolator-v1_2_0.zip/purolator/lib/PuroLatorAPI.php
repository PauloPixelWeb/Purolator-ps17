<?php
/**
 * 2010-2018 PixelWeb
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Software License Agreement that you can get at:
 * http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 *
 *  @author    PixelWeb <paulo@lievant.com>
 *  @copyright 2010-2018 Addons-Modules.com - Pixelweb.com.mx
 *  @license   http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 */

class PuroLatorAPI
{

    private $key;
    private $pass;
    private $token;
    private $services = array();
    private $test_mode = true;

    public function __construct($test_mode, $key, $pass, $token)
    {
        $this->test_mode = $test_mode;
        $this->key = $key;
        $this->pass = $pass;
        $this->token = $token;
        $this->services = array(
            'EstimatingService' => array(
                'wsdl_file_name' => 'EstimatingService',
                'service' => 'Estimating',
                'version' => '1.4'
            ),
            'ShippingService' => array(
                'wsdl_file_name' => 'ShippingService',
                'service' => 'Shipping',
                'version' => '1.6'
            ),
            'ShippingDocumentsService' => array(
                'wsdl_file_name' => 'ShippingDocumentsService',
                'service' => 'ShippingDocuments',
                'version' => '1.3'
            ),
            'TrackingService' => array(
                'wsdl_file_name' => 'TrackingService',
                'service' => 'Tracking',
                'version' => '1.2'
            )
        );
    }

    private function createPWSSOAPClient($function)
    {
        $client = new SoapClient(dirname(__FILE__) . "/wsdl/" . $this->services[$function]['wsdl_file_name'] . ".wsdl", array(
            'trace' => true,
            'location' => "https://" . ($this->test_mode ? 'dev' : '') . "webservices.purolator.com/PWS/V1/" . $this->services[$function]['service'] . "/" . $function . ".asmx",
            'uri' => "http://purolator.com/pws/datatypes/v1",
            'login' => $this->key,
            'password' => $this->pass
                )
        );
        $headers[] = new SoapHeader('http://purolator.com/pws/datatypes/v1', 'RequestContext', array(
            'Version' => $this->services[$function]['version'],
            'Language' => 'en',
            'GroupID' => 'xxx',
            'RequestReference' => 'Purolator Module for Prestashop',
            'UserToken' => $this->token
                )
        );
        $client->__setSoapHeaders($headers);

        return $client;
    }

    /**
     * Calculate shipment cost
     * 
     * @param array $params Array for services params
     * @param array $errors By reference var for errors
     * @return bool|array array of stdObject for correct response or FALSE if errors.
     */
    public function getEstimateCost($params, &$errors)
    {
        $client = $this->createPWSSOAPClient('EstimatingService');

        try
        {
            $response = $client->GetQuickEstimate($params);
        }
        catch (SoapFault $e)
        {
            $errors[] = 'SoapFault (Code #' . $e->faultcode . ') ' . $e->faultstring;
            return false;
        }

        if ($errors = $this->checkErrors($response))
            return false;

        if (count($response->ShipmentEstimates->ShipmentEstimate) == 1)
            return array($response->ShipmentEstimates->ShipmentEstimate);
        else
            return $response->ShipmentEstimates->ShipmentEstimate;
    }

    /**
     * Generate a shipment
     * 
     * @param array $params Array for services params
     * @param array $errors By reference var for errors
     * @return bool|string ShipmentPIN for correct response or FALSE if errors.
     */
    public function generateShipment($params, &$errors)
    {
        $client = $this->createPWSSOAPClient('ShippingService');

        try
        {
            $response = $client->CreateShipment($params);
        }
        catch (SoapFault $e)
        {
            $errors[] = 'SoapFault (Code #' . $e->faultcode . ') ' . $e->faultstring;
            return false;
        }

        if ($errors = $this->checkErrors($response))
            return false;

        return $response->ShipmentPIN->Value;
    }

    /**
     * Validate a shipment
     * 
     * @param array $params Array for services params
     * @param array $errors By reference var for errors
     * @return bool.
     */
    public function validateShipment($params, &$errors)
    {
        $client = $this->createPWSSOAPClient('ShippingService');

        try
        {
            $response = $client->ValidateShipment($params);
        }
        catch (SoapFault $e)
        {
            $errors[] = 'SoapFault (Code #' . $e->faultcode . ') ' . $e->faultstring;
            return false;
        }

        if ($errors = $this->checkErrors($response))
            return false;

        return $response->ValidShipment;
    }

    /**
     * Cancel a shipment
     * 
     * @param array $params Array for services params
     * @param array $errors By reference var for errors
     * @return bool.
     */
    public function cancelShipment($params, &$errors)
    {
        $client = $this->createPWSSOAPClient('ShippingService');

        try
        {
            $response = $client->VoidShipment($params);
        }
        catch (SoapFault $e)
        {
            $errors[] = 'SoapFault (Code #' . $e->faultcode . ') ' . $e->faultstring;
            return false;
        }

        if ($errors = $this->checkErrors($response))
            return false;

        return $response->ShipmentVoided;
    }

    /**
     * Consolidate a shipment
     * 
     * @param array $params Array for services params
     * @param array $errors By reference var for errors
     * @return bool|string ShipmentPIN for correct response or FALSE if errors.
     */
    public function consolidateShipment($params, &$errors)
    {
        $client = $this->createPWSSOAPClient('ShippingService');

        try
        {
            $response = $client->Consolidate($params);
        }
        catch (SoapFault $e)
        {
            $errors[] = 'SoapFault (Code #' . $e->faultcode . ') ' . $e->faultstring;
            return false;
        }

        if ($errors = $this->checkErrors($response))
            return false;

        return $response->Consolidate;
    }

    /**
     * Get a shipment document
     * 
     * @param array $params Array for services params
     * @param array $errors By reference var for errors
     * @return bool|string Document URL for correct response or FALSE if errors.
     */
    public function getDocuments($params, &$errors)
    {
        $client = $this->createPWSSOAPClient('ShippingDocumentsService');

        try
        {
            $response = $client->GetDocuments($params);
        }
        catch (SoapFault $e)
        {
            $errors[] = 'SoapFault (Code #' . $e->faultcode . ') ' . $e->faultstring;
            return false;
        }

        if ($errors = $this->checkErrors($response))
            return false;

        if ($response->Documents->Document->DocumentDetails->DocumentDetail->DocumentStatus == 'Completed')
            return $response->Documents->Document->DocumentDetails->DocumentDetail->URL;

        return false;
    }

    /**
     * Get a shipment delivered signature proof
     * 
     * @param array $params Array for services params
     * @param array $errors By reference var for errors
     * @return bool|string Document URL for correct response or FALSE if errors.
     */
    public function getDeliveredProof($params, &$errors)
    {
        $client = $this->createPWSSOAPClient('TrackingService');

        try
        {
            $response = $client->GetDeliveryDetails($params);
        }
        catch (SoapFault $e)
        {
            $errors[] = 'SoapFault (Code #' . $e->faultcode . ') ' . $e->faultstring;
            return false;
        }

        if ($errors = $this->checkErrors($response))
            return false;

        if (isset($response->DeliveryDetails->ScanDetails->SignatureImage) && $response->DeliveryDetails->ScanDetails->SignatureImage)
            return $response->DeliveryDetails;

        return false;
    }

    private function checkErrors($response)
    {
        $errors = [];
        if (isset($response->ResponseInformation->Errors->Error) && ($cant = count($response->ResponseInformation->Errors->Error)))
        {
            if ($cant == 1)
                $response->ResponseInformation->Errors->Error = array($response->ResponseInformation->Errors->Error);
            foreach ($response->ResponseInformation->Errors->Error as $error)
                $errors[] = '(Code #' . $error->Code . ') ' . $error->Description;
        }
        return $errors;
    }

}
