<?php
/**
 * 2010-2018 PixelWeb
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Software License Agreement that you can get at:
 * http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 *
 *  @author    PixelWeb <paulo@lievant.com>
 *  @copyright 2010-2018 Addons-Modules.com - Pixelweb.com.mx
 *  @license   http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 */

class PuroLatorLog
{

    public static function mensaje($mensaje, $level)
    {
        if (Configuration::getGlobalValue('PUROLATOR_LOG'))
        {
            $archivo = dirname(__FILE__) . '/purolator.log';
            $manejador = fopen($archivo, 'a');
            fwrite($manejador, "[" . date("r") . "] PrestaShop ver:" . _PS_VERSION_ . " -> $level: $mensaje\n\r");
            fclose($manejador);
        }
    }

    public static function error($mensaje)
    {
        $level = 'ERROR';
        self::mensaje($mensaje, $level);
    }

    public static function info($mensaje)
    {
        $level = 'INFO';
        self::mensaje($mensaje, $level);
    }

}
