<?php
/**
 * 2010-2018 PixelWeb
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Software License Agreement that you can get at:
 * http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 *
 *  @author    PixelWeb <paulo@lievant.com>
 *  @copyright 2010-2018 Addons-Modules.com - Pixelweb.com.mx
 *  @license   http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 */
@ini_set('display_errors,1');

if (!defined('_PS_VERSION_'))
    exit;

include_once(dirname(__FILE__) . '/PuroLatorLog.php');
include_once(dirname(__FILE__) . '/lib/PuroLatorAPI.php');

class PuroLator extends CarrierModule
{

    const WEBSERVICE_CURRENCY = 'USD';

    private $services;
    public $id_carrier = 0;
    private $_html = '';



    public function __construct()
    {
        $this->name = 'purolator';
        $this->tab = 'shipping_logistics';
        $this->version = '1.2.1';
        $this->author = 'PixelWeb';
								$this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->module_key = '997b8d507791a507cde7764c499e58f8';

        if (version_compare(_PS_VERSION_, '1.7.0', '>=') === true)
            $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('PuroLator Shipping');
        $this->description = $this->l('Allow to generate your order packages guides with PuroLator shipping.');
								
								if (!Configuration::get('purolator'))
										$this->warning = $this->l('No name provided');

        if (!Currency::getIdByIsoCode(self::WEBSERVICE_CURRENCY))
            $this->warning = sprintf($this->l('You must have %s as currency in your shop to calculate shipping cost properly.'), self::WEBSERVICE_CURRENCY);

        //Remember that the ID of the services containing 1030AM or 1200 are like this 10:30 AM or 12:00 at the time of sending it to the webservice
        $this->services = array(
            'PurolatorExpress9AM' => 'Purolator Express 9AM',
            'PurolatorExpressEnvelope9AM' => 'Purolator Express Envelope 9AM',
            'PurolatorExpressPack9AM' => 'Purolator Express Pack 9AM',
            'PurolatorExpressBox9AM' => 'Purolator Express Box 9AM',
            'PurolatorExpress1030AM' => 'Purolator Express 10:30AM',
            'PurolatorExpressEnvelope1030AM' => 'Purolator Express Envelope 10:30AM',
            'PurolatorExpressPack1030AM' => 'Purolator Express Pack 10:30AM',
            'PurolatorExpressBox1030AM' => 'Purolator Express Box 10:30AM',
            'PurolatorExpress' => 'Purolator Express',
            'PurolatorExpressEnvelope' => 'Purolator Express Envelope',
            'PurolatorExpressPack' => 'Purolator Express Pack',
            'PurolatorExpressBox' => 'Purolator Express Box',
            'PurolatorExpressEvening' => 'Purolator Express Evening',
            'PurolatorExpressEnvelopeEvening' => 'Purolator Express Envelope Evening',
            'PurolatorExpressPackEvening' => 'Purolator Express Pack Evening',
            'PurolatorExpressBoxEvening' => 'Purolator Express Box Evening',
            'PurolatorGround9AM' => 'Purolator Ground 9AM',
            'PurolatorGround1030AM' => 'Purolator Ground 10:30AM',
            'PurolatorGround' => 'Purolator Ground',
            'PurolatorGroundEvening' => 'Purolator Ground Evening',
            'PurolatorGroundDistribution' => 'Purolator Ground Distribution',
            'PurolatorExpressU.S.9AM' => 'Purolator Express U.S. 9AM',
            'PurolatorExpressU.S.Envelope9AM' => 'Purolator Express U.S. Envelope 9AM',
            'PurolatorExpressU.S.Pack9AM' => 'Purolator Express U.S. Pack 9AM',
            'PurolatorExpressU.S.Box9AM' => 'Purolator Express U.S. Box 9AM',
            'PurolatorExpressU.S.1030AM' => 'Purolator Express U.S. 10:30AM',
            'PurolatorExpressU.S.Envelope1030AM' => 'Purolator Express U.S. Envelope 10:30AM',
            'PurolatorExpressU.S.Pack1030AM' => 'Purolator Express U.S. Pack 10:30AM',
            'PurolatorExpressU.S.Box1030AM' => 'Purolator Express U.S. Box 10:30AM',
            'PurolatorExpressU.S.1200' => 'Purolator Express U.S. 12PM',
            'PurolatorExpressU.S.Envelope1200' => 'Purolator Express U.S. Envelope 12PM',
            'PurolatorExpressU.S.Pack1200' => 'Purolator Express U.S. Pack 12PM',
            'PurolatorExpressU.S.Box1200' => 'Purolator Express U.S. Box 12PM',
            'PurolatorExpressU.S.' => 'Purolator Express U.S.',
            'PurolatorExpressEnvelopeU.S.' => 'Purolator Express Envelope U.S.',
            'PurolatorExpressPackU.S.' => 'Purolator Express Pack U.S.',
            'PurolatorExpressBoxU.S.' => 'Purolator Express Box U.S.',
            'PurolatorGroundU.S.' => 'Purolator Ground U.S.',
            'PurolatorExpressInternational9AM' => 'Purolator Express International 9AM',
            'PurolatorExpressInternationalEnvelope9AM' => 'Purolator Express International Envelope 9AM',
            'PurolatorExpressInternationalPack9AM' => 'Purolator Express International Pack 9AM',
            'PurolatorExpressInternationalBox9AM' => 'Purolator Express International Box 9AM',
            'PurolatorExpressInternational1030AM' => 'Purolator Express International 10:30AM',
            'PurolatorExpressInternationalEnvelope1030AM' => 'Purolator Express International Envelope 10:30AM',
            'PurolatorExpressInternationalPack1030AM' => 'Purolator Express International Pack 10:30AM',
            'PurolatorExpressInternationalBox1030AM' => 'Purolator Express International Box 10:30AM',
            'PurolatorExpressInternational1200' => 'Purolator Express International 12PM',
            'PurolatorExpressInternationalEnvelope1200' => 'Purolator Express International Envelope 12PM',
            'PurolatorExpressInternationalPack1200' => 'Purolator Express International Pack 12PM',
            'PurolatorExpressInternationalBox1200' => 'Purolator Express International Box 12PM',
            'PurolatorExpressInternational' => 'Purolator Express International',
            'PurolatorExpressEnvelopeInternational' => 'Purolator Express International Envelope',
            'PurolatorExpressPackInternational' => 'Purolator Express International Pack',
            'PurolatorExpressBoxInternational' => 'Purolator Express International Box'
        );
    }

    public function install()
    {
        $query = "CREATE TABLE IF NOT EXISTS " . _DB_PREFIX_ . "purolator_envio (
                    id_purolator_envio int(10) unsigned NOT NULL Key AUTO_INCREMENT,
                    id_order int(10) NOT NULL,
                    status enum('generated', 'consolidated', 'canceled', 'delivered') NOT NULL DEFAULT 'generated',
                    pin varchar(20) NULL,
                    url varchar(300) NULL,
                    date_delivered datetime NULL,
                    delivered_file varchar(20) NULL,
                    date_add datetime,
                    date_upd datetime)";
        Db::getInstance()->execute($query);
        $query = "CREATE TABLE IF NOT EXISTS " . _DB_PREFIX_ . "purolator_carrier (
                    id_carrier int(10) unsigned NOT NULL,
                    service varchar(100) NULL,
                    active tinyint(1) NOT NULL DEFAULT 1)";
        Db::getInstance()->execute($query);

        Configuration::updateGlobalValue('PUROLATOR_KEY');
        Configuration::updateGlobalValue('PUROLATOR_PASS', '');
        Configuration::updateGlobalValue('PUROLATOR_BILLING_ACCOUNT', '');
        Configuration::updateGlobalValue('PUROLATOR_REGISTERED_ACCOUNT', '');
        Configuration::updateGlobalValue('PUROLATOR_USER_TOKEN', '');
        Configuration::updateGlobalValue('PUROLATOR_LOG', 0);
        Configuration::updateGlobalValue('PUROLATOR_POSTCODE', '');
        Configuration::updateGlobalValue('PUROLATOR_PACKAGE_TYPE', 'CustomerPackaging');
        Configuration::updateGlobalValue('PUROLATOR_NAME', '');
        Configuration::updateGlobalValue('PUROLATOR_COMPANY', '');
        Configuration::updateGlobalValue('PUROLATOR_DEPARTMENT', '');
        Configuration::updateGlobalValue('PUROLATOR_STREET_NAME', '');
        Configuration::updateGlobalValue('PUROLATOR_STREET_NUMBER', '');
        Configuration::updateGlobalValue('PUROLATOR_STREET_TYPE', 'Street');
        Configuration::updateGlobalValue('PUROLATOR_CITY', '');
        Configuration::updateGlobalValue('PUROLATOR_PROVINCE', '');
        Configuration::updateGlobalValue('PUROLATOR_COUNTRY', '');
        Configuration::updateGlobalValue('PUROLATOR_PHONE_AC', '000');
        Configuration::updateGlobalValue('PUROLATOR_PHONE', '');
        Configuration::updateGlobalValue('PUROLATOR_DOC_TYPE', 'DomesticBillOfLading');
        Configuration::updateGlobalValue('PUROLATOR_SIGNATURE', '1');
        Configuration::updateGlobalValue('PUROLATOR_EMAIL', Configuration::get('PS_SHOP_EMAIL'));
        Configuration::updateGlobalValue('PUROLATOR_NOTIFY', '0');
        Configuration::updateGlobalValue('PUROLATOR_WORTH', '0');
        Configuration::updateGlobalValue('PUROLATOR_PRINTER_TYPE', 'Regular');
        Configuration::updateGlobalValue('PUROLATOR_PICKUP_TYPE', 'DropOff');
        Configuration::updateGlobalValue('PUROLATOR_WEIGHT', '1');
        Configuration::updateGlobalValue('PUROLATOR_MODE_TEST', 1);

        $tab = new Tab();
        $tab->class_name = 'AdminPuroLator';
        $tab->id_parent = Tab::getIdFromClassName('AdminParentOrders');
        $tab->module = $this->name;
        $languages = Language::getLanguages();
        foreach ($languages as $language)
            if ($language['iso_code'] == 'es')
                $tab->name[$language['id_lang']] = 'Transportista PuroLator';
            elseif ($language['iso_code'] == 'en')
                $tab->name[$language['id_lang']] = 'PuroLator Shipping';
            elseif ($language['iso_code'] == 'fr')
                $tab->name[$language['id_lang']] = 'Transportista PuroLator';
            else
                $tab->name[$language['id_lang']] = $this->displayName;
        $tab->add();

        if (!parent::install() || !$this->registerHook('updateCarrier') || !$this->registerHook('displayAdminOrder'))
            return false;

        return true;
    }

    public function uninstall()
    {
 
					   $id_tab = Tab::getIdFromClassName('AdminPuroLator');
        if ($id_tab)
        {
            $tab = new Tab($id_tab);
            $tab->delete();
        }

        $purolator_carriers = Db::getInstance()->executeS('SELECT id_carrier FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE active=1');
        foreach ($purolator_carriers as $carrier)
        {
            $carrier = new Carrier((int) $carrier['id_carrier']);
            $carrier->deleted = 1;
            $carrier->update();
        }
        Db::getInstance()->Execute('DROP table ' . _DB_PREFIX_ . 'purolator_envio');
        Db::getInstance()->Execute('DROP table ' . _DB_PREFIX_ . 'purolator_carrier');

        return (parent::uninstall() &&
                Configuration::deleteByName('PUROLATOR_KEY') &&
                Configuration::deleteByName('PUROLATOR_PASS') &&
                Configuration::deleteByName('PUROLATOR_BILLING_ACCOUNT') &&
                Configuration::deleteByName('PUROLATOR_REGISTERED_ACCOUNT') &&
                Configuration::deleteByName('PUROLATOR_USER_TOKEN') &&
                Configuration::deleteByName('PUROLATOR_POSTCODE') &&
                Configuration::deleteByName('PUROLATOR_PACKAGE_TYPE') &&
                Configuration::deleteByName('PUROLATOR_NAME') &&
                Configuration::deleteByName('PUROLATOR_COMPANY') &&
                Configuration::deleteByName('PUROLATOR_DEPARTMENT') &&
                Configuration::deleteByName('PUROLATOR_STREET_NAME') &&
                Configuration::deleteByName('PUROLATOR_STREET_NUMBER') &&
                Configuration::deleteByName('PUROLATOR_STREET_TYPE') &&
                Configuration::deleteByName('PUROLATOR_CITY') &&
                Configuration::deleteByName('PUROLATOR_PROVINCE') &&
                Configuration::deleteByName('PUROLATOR_COUNTRY') &&
                Configuration::deleteByName('PUROLATOR_PHONE_AC') &&
                Configuration::deleteByName('PUROLATOR_PHONE') &&
                Configuration::deleteByName('PUROLATOR_DOC_TYPE') &&
                Configuration::deleteByName('PUROLATOR_SIGNATURE') &&
                Configuration::deleteByName('PUROLATOR_EMAIL') &&
                Configuration::deleteByName('PUROLATOR_DOC_TYPE') &&
                Configuration::deleteByName('PUROLATOR_NOTIFY') &&
                Configuration::deleteByName('PUROLATOR_PRINTER_TYPE') &&
                Configuration::deleteByName('PUROLATOR_PICKUP_TYPE') &&
                Configuration::deleteByName('PUROLATOR_WEIGHT') &&
                Configuration::deleteByName('PUROLATOR_MODE_TEST')
                );
    }

    private function installExternalCarrier($config)
    {
        $carrier = new Carrier();
        $carrier->name = $config['name'];
        $carrier->id_tax_rules_group = $config['id_tax_rules_group'];
        $carrier->id_zone = $config['id_zone'];
        $carrier->active = $config['active'];
        $carrier->deleted = $config['deleted'];
        $carrier->delay = $config['delay'];
        $carrier->shipping_handling = $config['shipping_handling'];
        $carrier->range_behavior = $config['range_behavior'];
        $carrier->is_module = $config['is_module'];
        $carrier->shipping_external = $config['shipping_external'];
        $carrier->external_module_name = $config['external_module_name'];
        $carrier->need_range = $config['need_range'];
        $carrier->url = 'https://www.purolator.com/purolator/ship-track/tracking-summary.page?pin=@';

        $languages = Language::getLanguages(true);
        foreach ($languages as $language)
            $carrier->delay[(int) $language['id_lang']] = $config['delay'][$language['iso_code']];

        if ($carrier->add())
        {

            $groups_ids = array();
            $groups = Group::getGroups(Context::getContext()->language->id);
            foreach ($groups as $group)
																	$groups_ids[] = $group['id_group'];
																	$carrier->setGroups($groups_ids);
																		
																	
																	$rangePrice = new RangePrice();
																	$rangePrice->id_carrier = $carrier->id;
																	$rangePrice->delimiter1 = '0';
																	$rangePrice->delimiter2 = '1000000000';
																	$rangePrice->add();

																	$rangeWeight = new RangeWeight();
																	$rangeWeight->id_carrier = $carrier->id;
																	$rangeWeight->delimiter1 = '0';
																	$rangeWeight->delimiter2 = '1000000000';
																	$rangeWeight->add();
																	
																	ImageManager::resize(dirname(__FILE__) . '/views/img/purolator.png', _PS_SHIP_IMG_DIR_ . '/' . (int) $carrier->id . '.jpg');

																	$zones = Zone::getZones(true);
																	foreach ($zones as $zone)
																	{
																					$carrier->addZone($zone['id_zone']);
																	}

																	return (int) ($carrier->id);
        }

        return false;
    }

    public function getContent()
    {
        
								
								if (Tools::isSubmit('submitSave'))

            if ($this->preProcess())
            {
                $form_values = $this->getConfigFieldsValues(false);
																
                foreach (array_keys($form_values) as $key)
                    Configuration::updateGlobalValue($key, Tools::getValue($key));


                if ($selected_services = Tools::getValue('groupBox'))
                {
                    foreach ($selected_services as $id_service)
                    //if is not active or no exist
                        if (!Db::getInstance()->getValue('SELECT active FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE service="' . $id_service . '"'))
                        {
                            //if exist is because it was inactive
                            if ($id_carrier = Db::getInstance()->getValue('SELECT id_carrier FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE service="' . $id_service . '"'))
                            {
                                $carrier = new Carrier((int) $id_carrier);
                                $carrier->active = 1;
                                $carrier->update();
                                Db::getInstance()->update('purolator_carrier', array('active' => 1), 'id_carrier=' . (int) $id_carrier);
                            }
                            //if it is not active, adding!!!
                            else
                            {
                                $delay = array(
                                    'es' => 'Purolator promete entrega.',
                                    'en' => 'Purolator promises delivered.',
                                    'fr' => 'Purolator promet livré.',
                                );
                                foreach (Language::getLanguages() as $lang)
                                    if (!array_key_exists($lang['iso_code'], $delay))
                                        $delay[$lang['iso_code']] = 'Purolator promises delivered.';
                                $carrierConfig = array('name' => $this->services[$id_service],
                                    'id_tax_rules_group' => 0,
                                    'active' => true,
                                    'deleted' => 0,
                                    'shipping_handling' => false,
                                    'range_behavior' => 0,
                                    'delay' => $delay,
                                    'id_zone' => 2,
                                    'is_module' => true,
                                    'shipping_external' => true,
                                    'external_module_name' => $this->name,
                                    'need_range' => true
                                );
                                $id_carrier = $this->installExternalCarrier($carrierConfig);
                                Db::getInstance()->insert('purolator_carrier', array('id_carrier' => $id_carrier, 'service' => $id_service));
                            }
                        }
                }
                else
                    $selected_services = array();
                $deselected_carriers = Db::getInstance()->executeS('SELECT id_carrier FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE active=1 AND service NOT IN ("' . implode('","', $selected_services) . '")');
                foreach ($deselected_carriers as $carrier_data)
                {
                    $carrier = new Carrier((int) $carrier_data['id_carrier']);
                    $carrier->active = 0;
                    $carrier->update();
                    Db::getInstance()->update('purolator_carrier', array('active' => 0), 'id_carrier=' . (int) $carrier_data['id_carrier']);
                }

                $this->_html .= $this->displayConfirmation($this->l('Configuration saved successfully.'));
            
												
												}



        $this->renderForm();
        return $this->_html;
    }

    private function preProcess()
    {
        $types = array('Abbey', 'End', 'Montéé', 'Village', 'Acres', 'Esplanade', 'Mount', 'Villas', 'Allée', 'Estates', 'Mountain', 'Vista',
            'Alley', 'Expressway', 'Parade', 'Voie', 'Autoroute', 'Extension', 'Parc', 'Walk', 'avenue', 'Field', 'Park', 'Way', 'Avenue', 'Forest',
            'Parkway', 'Wharf', 'Bay', 'Freeway', 'Passage', 'Wood', 'Beach', 'Front', 'Path', 'Wynd', 'Bend', 'Gardens', 'Pathway', 'Boulevard',
            'Gate', 'Pines', 'Branch', 'Glade', 'Place', 'By-pass', 'Glen', 'Plateau', 'Campus', 'Green  Plaza', 'Cape', 'Grounds', 'Point', 'Carré',
            'Grove', 'Pointe', 'Carrefour', 'Harbour', 'Port', 'Centre', 'Heath', 'Private', 'Cercle', 'Height', 'Promenade', 'Chase', 'Heights',
            'Quai', 'Chemin', 'Highlands', 'Quay', 'Circle', 'Highway', 'Ramp', 'Circuit', 'Hill', 'Rang', 'Close', 'Hollow', 'Ridge', 'Common',
            'Île', 'Rise', 'Concession', 'Impasse', 'Road', 'Corners', 'Inlet  Route', 'Côte', 'Island', 'Row', 'Cour', 'Key', 'Rue', 'Cours  Knoll',
            'Ruelle', 'Court', 'Landing', 'Run', 'Cove', 'Lane', 'Sentier', 'Crest  Limits', 'Square', 'Crescent', 'Line', 'Street', 'Croissant',
            'Link', 'Subdivision', 'Crossing', 'Lookout', 'Terrace', 'Cul-de-sac', 'Loop', 'Terrasse', 'Dale', 'Mall', 'Townline', 'Dell', 'Manor',
            'Trail', 'Diversion', 'Maze', 'Turnabout', 'Downs', 'Meadow', 'Vale', 'Drive', 'Mews', 'View');
        $doc_types = array('COSBillOfLading', 'CustomsInvoice', 'CustomsInvoiceThermal', 'DangerousGoodsDeclaration', 'DomesticBillOfLading', 'DomesticBillOfLadingThermal', 'ExpressChequeReceipt', 'ExpressChequeReceiptThermal', 'FCC740', 'FDA2877', 'InternationalBillOfLading', 'InternationalBillOfLadingThermal', 'NAFTA');
        if (!Tools::getValue('PUROLATOR_KEY'))
            $this->_html .= $this->displayError($this->l('Purolator Key configuration is invalid. Value can\'t be empty.'));
        elseif (!Tools::getValue('PUROLATOR_PASS'))
            $this->_html .= $this->displayError($this->l('Purolator Password configuration is invalid. Value can\'t be empty.'));
        elseif (!Tools::getValue('PUROLATOR_USER_TOKEN'))
            $this->_html .= $this->displayError($this->l('User Token configuration is invalid. Value can\'t be empty.'));
        elseif (!(($billing_account = Tools::getValue('PUROLATOR_BILLING_ACCOUNT')) && is_numeric($billing_account)))
            $this->_html .= $this->displayError($this->l('Billing Account configuration is invalid. Must be a numeric value.'));
        elseif (!(($registered_account = Tools::getValue('PUROLATOR_REGISTERED_ACCOUNT')) && is_numeric($registered_account)))
            $this->_html .= $this->displayError($this->l('Registered Account configuration is invalid. Must be a numeric value.'));
        elseif (!(($name = Tools::getValue('PUROLATOR_NAME')) && Tools::strlen($name) <= 30))
            $this->_html .= $this->displayError($this->l('Sender Name configuration is invalid. Must have less than 30 char lenght.'));
        elseif ((($company = Tools::getValue('PUROLATOR_COMPANY')) && Tools::strlen($company) > 30))
            $this->_html .= $this->displayError($this->l('Sender Company configuration is invalid. Must have less than 30 char lenght.'));
        elseif ((($department = Tools::getValue('PUROLATOR_DEPARTMENT')) && Tools::strlen($department) > 20))
            $this->_html .= $this->displayError($this->l('Sender Deparment configuration is invalid. Must have less than 20 char lenght.'));
        elseif (!(($st_name = Tools::getValue('PUROLATOR_STREET_NAME')) && Tools::strlen($st_name) <= 30))
            $this->_html .= $this->displayError($this->l('Sender Street Name configuration is invalid. Must have less than 30 char lenght.'));
        elseif (!(($st_number = Tools::getValue('PUROLATOR_STREET_NUMBER')) && Tools::strlen($st_number) <= 6))
            $this->_html .= $this->displayError($this->l('Sender Street Number configuration is invalid. Must have less than 6 char lenght.'));
        elseif (!(($st_type = Tools::getValue('PUROLATOR_STREET_TYPE')) && in_array($st_type, $types)))
            $this->_html .= $this->displayError($this->l('Sender Street Type configuration is invalid. Must be one of the displayed list.'));
        elseif (!(($city = Tools::getValue('PUROLATOR_CITY')) && Tools::strlen($city) <= 30))
            $this->_html .= $this->displayError($this->l('Sender City configuration is invalid. Must have less than 30 char lenght.'));
        elseif (!(($country = Tools::getValue('PUROLATOR_COUNTRY')) && Validate::isStateIsoCode($country)))
            $this->_html .= $this->displayError($this->l('Sender Country configuration is invalid. Must be one of the displayed list.'));
        elseif (!(($province = Tools::getValue('PUROLATOR_PROVINCE')) && Validate::isStateIsoCode($province) && State::getIdByIso($province, Country::getByIso($country))))
            $this->_html .= $this->displayError($this->l('Sender Province Code configuration is invalid. Must be a valid province or state ISO code of' . ' ' . Country::getNameById($this->context->language->id, Country::getByIso($country))));
        elseif (!(($postcode = Tools::getValue('PUROLATOR_POSTCODE')) && Validate::isPostCode($postcode)))
            $this->_html .= $this->displayError($this->l('Sender Postcode configuration is invalid. Must be a valid postcode.'));
        elseif (!(($phone_ac = Tools::getValue('PUROLATOR_PHONE_AC')) && Tools::strlen($phone_ac) == 3 && is_numeric($phone_ac)))
            $this->_html .= $this->displayError($this->l('Sender Phone Number Area Code configuration is invalid. Must be a numeric value with 3 char lenght.'));
        elseif (!(($phone = Tools::getValue('PUROLATOR_PHONE')) && Tools::strlen($phone) <= 7 && is_numeric($phone)))
            $this->_html .= $this->displayError($this->l('Sender Phone configuration is invalid. Must be a numeric value with 7 char lenght.'));
        elseif (!Tools::getValue('groupBox'))
            $this->_html .= $this->displayError($this->l('You must select at least one service to activate Purolator Carrier.'));
        elseif (!(($doc_type = Tools::getValue('PUROLATOR_DOC_TYPE')) && in_array($doc_type, $doc_types)))
            $this->_html .= $this->displayError($this->l('Document Type configuration is invalid. Must be one of the displayed list.'));
        elseif ((($email = Tools::getValue('PUROLATOR_EMAIL')) && !Validate::isEmail($email)))
            $this->_html .= $this->displayError($this->l('Notify Myself to Email configuration is invalid. Must have a valid email format.'));
        elseif (!(($printer_type = Tools::getValue('PUROLATOR_PRINTER_TYPE')) && in_array($printer_type, array('Regular', 'Thermal'))))
            $this->_html .= $this->displayError($this->l('Printer Type configuration is invalid. Must be one of the displayed list.'));
        elseif (!(($pickup_type = Tools::getValue('PUROLATOR_PICKUP_TYPE')) && in_array($pickup_type, array('DropOff', 'PreScheduled'))))
            $this->_html .= $this->displayError($this->l('Pickup Type configuration is invalid. Must be one of the displayed list.'));
        elseif (!(($weight = Tools::getValue('PUROLATOR_WEIGHT')) && Validate::isFloat($weight)))
            $this->_html .= $this->displayError($this->l('Default Weight configuration is invalid. Must be a valid floating number.'));
        else
            return true;
    }

    public function renderForm()
    {
        $available_services = array();
        foreach ($this->services as $id => $name)
            $available_services[] = array('id_group' => $id, 'name' => $name);
        $street_types = array();
        $types = array('Abbey', 'End', 'Montéé', 'Village', 'Acres', 'Esplanade', 'Mount', 'Villas', 'Allée', 'Estates', 'Mountain', 'Vista',
            'Alley', 'Expressway', 'Parade', 'Voie', 'Autoroute', 'Extension', 'Parc', 'Walk', 'avenue', 'Field', 'Park', 'Way', 'Avenue', 'Forest',
            'Parkway', 'Wharf', 'Bay', 'Freeway', 'Passage', 'Wood', 'Beach', 'Front', 'Path', 'Wynd', 'Bend', 'Gardens', 'Pathway', 'Boulevard',
            'Gate', 'Pines', 'Branch', 'Glade', 'Place', 'By-pass', 'Glen', 'Plateau', 'Campus', 'Green  Plaza', 'Cape', 'Grounds', 'Point', 'Carré',
            'Grove', 'Pointe', 'Carrefour', 'Harbour', 'Port', 'Centre', 'Heath', 'Private', 'Cercle', 'Height', 'Promenade', 'Chase', 'Heights',
            'Quai', 'Chemin', 'Highlands', 'Quay', 'Circle', 'Highway', 'Ramp', 'Circuit', 'Hill', 'Rang', 'Close', 'Hollow', 'Ridge', 'Common',
            'Île', 'Rise', 'Concession', 'Impasse', 'Road', 'Corners', 'Inlet  Route', 'Côte', 'Island', 'Row', 'Cour', 'Key', 'Rue', 'Cours  Knoll',
            'Ruelle', 'Court', 'Landing', 'Run', 'Cove', 'Lane', 'Sentier', 'Crest  Limits', 'Square', 'Crescent', 'Line', 'Street', 'Croissant',
            'Link', 'Subdivision', 'Crossing', 'Lookout', 'Terrace', 'Cul-de-sac', 'Loop', 'Terrasse', 'Dale', 'Mall', 'Townline', 'Dell', 'Manor',
            'Trail', 'Diversion', 'Maze', 'Turnabout', 'Downs', 'Meadow', 'Vale', 'Drive', 'Mews', 'View');
        sort($types);
        foreach ($types as $name)
            $street_types[] = array('id' => $name, 'name' => $name);
        $doc_types = array();
        $types = array('COSBillOfLading', 'CustomsInvoice', 'CustomsInvoiceThermal', 'DangerousGoodsDeclaration', 'DomesticBillOfLading', 'DomesticBillOfLadingThermal', 'ExpressChequeReceipt', 'ExpressChequeReceiptThermal', 'FCC740', 'FDA2877', 'InternationalBillOfLading', 'InternationalBillOfLadingThermal', 'NAFTA');
        sort($types);
        foreach ($types as $name)
            $doc_types[] = array('id' => $name, 'name' => $name);
        $log_url = Context::getContext()->shop->getBaseUrl() . '/modules/purolator/purolator.log';
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Configuration'),
                    'image' => '../modules/' . $this->name . '/logo.gif'
                ),
                'warning' => (Currency::getIdByIsoCode(self::WEBSERVICE_CURRENCY) ? false : sprintf($this->l('You must have %s as currency in your shop to calculate shipping cost properly.'), self::WEBSERVICE_CURRENCY)),
                'description' => $this->l('You can check log file at:') . ' <a target="_blank" href="' . $log_url . '">' . $log_url . '</a>',
                'input' => array(
                    array(
                        'type' => 'radio',
                        'label' => $this->l('Mode'),
                        'name' => 'PUROLATOR_MODE_TEST',
                        'required' => false,
                        'class' => 't',
                        'br' => true,
                        'values' => array(
                            array(
                                'id' => 'test',
                                'value' => 1,
                                'label' => $this->l('Test')
                            ),
                            array(
                                'id' => 'produccion',
                                'value' => 0,
                                'label' => $this->l('Production')
                            )
                        )
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Purolator Key'),
                        'name' => 'PUROLATOR_KEY',
                        'hint' => $this->l('PuroLator webservice authentication key.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Purolator Password'),
                        'name' => 'PUROLATOR_PASS',
                        'hint' => $this->l('PuroLator webservice authentication password.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('User Token'),
                        'name' => 'PUROLATOR_USER_TOKEN',
                        'hint' => $this->l('PuroLator webservice user token.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Billing Account'),
                        'name' => 'PUROLATOR_BILLING_ACCOUNT',
                        'hint' => $this->l('PuroLator billing account number.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Registered Account'),
                        'name' => 'PUROLATOR_REGISTERED_ACCOUNT',
                        'hint' => $this->l('PuroLator registered account number.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Name'),
                        'name' => 'PUROLATOR_NAME',
                        'maxlength' => 30,
                        'hint' => $this->l('Sender Name Information'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Company'),
                        'name' => 'PUROLATOR_COMPANY',
                        'maxlength' => 30
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Department'),
                        'name' => 'PUROLATOR_DEPARTMENT',
                        'maxlength' => 20
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Street Name'),
                        'name' => 'PUROLATOR_STREET_NAME',
                        'maxlength' => 30,
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Street Number'),
                        'name' => 'PUROLATOR_STREET_NUMBER',
                        'maxlength' => 6,
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Sender Street Type'),
                        'name' => 'PUROLATOR_STREET_TYPE',
                        'options' => array(
                            'query' => $street_types,
                            'id' => 'id',
                            'name' => 'name'
                        )
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender City'),
                        'name' => 'PUROLATOR_CITY',
                        'maxlength' => 30,
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Province ISO Code'),
                        'name' => 'PUROLATOR_PROVINCE',
                        'hint' => $this->l('Sender ISO Code of Province or State'),
                        'maxlength' => 3,
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Sender Country'),
                        'name' => 'PUROLATOR_COUNTRY',
                        'required' => true,
                        'options' => array(
                            'query' => Country::getCountries($this->context->language->id, false),
                            'id' => 'iso_code',
                            'name' => 'name'
                        )
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Postcode'),
                        'name' => 'PUROLATOR_POSTCODE',
                        'maxlength' => 10,
                        'hint' => $this->l('Purolator sender zip code.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Phone Number Area Code'),
                        'name' => 'PUROLATOR_PHONE_AC',
                        'maxlength' => 3,
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Sender Phone Number'),
                        'name' => 'PUROLATOR_PHONE',
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Cost Estimation Package Type'),
                        'name' => 'PUROLATOR_PACKAGE_TYPE',
                        'options' => array(
                            'query' => array(
                                array('id' => 'CustomerPackaging', 'name' => $this->l('Customer Packaging')),
                                array('id' => 'ExpressEnvelope', 'name' => $this->l('Express Envelope')),
                                array('id' => 'ExpressPack', 'name' => $this->l('Express Pack')),
                                array('id' => 'ExpressBox', 'name' => $this->l('Express Box'))
                            ),
                            'id' => 'id',
                            'name' => 'name'
                        ),
                        'hint' => $this->l('Default package type for shipping cost estimation.'),
                        'desc' => $this->l('This selection could restrict available services for customers.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Document Type'),
                        'name' => 'PUROLATOR_DOC_TYPE',
                        'options' => array(
                            'query' => $doc_types,
                            'id' => 'id',
                            'name' => 'name'
                        ),
                        'hint' => $this->l('Document type for printing.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Printer Type'),
                        'name' => 'PUROLATOR_PRINTER_TYPE',
                        'options' => array(
                            'query' => array(
                                array('id' => 'Regular', 'name' => $this->l('Regular')),
                                array('id' => 'Thermal', 'name' => $this->l('Thermal'))
                            ),
                            'id' => 'id',
                            'name' => 'name'
                        ),
                        'hint' => $this->l('Sets the document type flag for either documents to be printed on a thermal printer, or documents to be printed on a laser printer.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Pickup Type'),
                        'name' => 'PUROLATOR_PICKUP_TYPE',
                        'options' => array(
                            'query' => array(
                                array('id' => 'DropOff', 'name' => $this->l('Drop Off')),
                                array('id' => 'PreScheduled', 'name' => $this->l('Pre Scheduled Pickup'))
                            ),
                            'id' => 'id',
                            'name' => 'name'
                        ),
                        'hint' => $this->l('Default pickup type for shipping cost estimation.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Request Receiver Signature on Delivery?'),
                        'name' => 'PUROLATOR_SIGNATURE',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Include Package Worth?'),
                        'name' => 'PUROLATOR_WORTH',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                        'desc' => $this->l('If you include the value of your shipment, you may be entitled to a payment if an issue occurs.') .
                        '</br><b>' . $this->l('Shipments with a declared value of $100 or less') . ':</b> ' .
                        $this->l('No surcharge will be applied if your shipment has a declared value of $100 or less.') .
                        '</br><b>' . $this->l('Shipments with a declared value over $100') . ':</b> ' .
                        $this->l('Purolator will cover the first $100 of declared value of your shipment at no extra cost, however a surcharge of 4.5% will apply to the declared value over $100.')
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Notify Client when Exception or Delivery Occurs?'),
                        'name' => 'PUROLATOR_NOTIFY',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Default Weight'),
                        'name' => 'PUROLATOR_WEIGHT',
                        'prefix' => Configuration::getGlobalValue('PS_WEIGHT_UNIT'),
                        'hint' => $this->l('Default value for products without weight value configured. This value will be multiplied by product quantity in order to sum total order weight.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Notify Myself to Email'),
                        'prefix' => '<i class="icon-envelope-o"></i>',
                        'name' => 'PUROLATOR_EMAIL',
                        'hint' => $this->l('Left in blank for not receiving notifications.')
                    ),
                    array(
                        'type' => 'group',
                        'label' => $this->l('Available Services'),
                        'name' => 'PUROLATOR_SERVICES',
                        'values' => $available_services,
                        'hint' => $this->l('Purolator available services for customer order shipping.'),
                        'required' => true
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Save Webservice Logs?'),
                        'name' => 'PUROLATOR_LOG',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save')
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitSave';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        $this->_html .= $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues($include_services = true)
    {
        $fields_value = array();
        if ($include_services)
            foreach (array_keys($this->services) as $id)
                $fields_value['groupBox_' . $id] = Tools::getValue('groupBox_' . $id, Db::getInstance()->getValue('SELECT active FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE service="' . $id . '"'));
        return array_merge($fields_value, array(
            'PUROLATOR_KEY' => Tools::getValue('PUROLATOR_KEY', Configuration::getGlobalValue('PUROLATOR_KEY')),
            'PUROLATOR_PASS' => Tools::getValue('PUROLATOR_PASS', Configuration::getGlobalValue('PUROLATOR_PASS')),
            'PUROLATOR_BILLING_ACCOUNT' => Tools::getValue('PUROLATOR_BILLING_ACCOUNT', Configuration::getGlobalValue('PUROLATOR_BILLING_ACCOUNT')),
            'PUROLATOR_REGISTERED_ACCOUNT' => Tools::getValue('PUROLATOR_REGISTERED_ACCOUNT', Configuration::getGlobalValue('PUROLATOR_REGISTERED_ACCOUNT')),
            'PUROLATOR_USER_TOKEN' => Tools::getValue('PUROLATOR_USER_TOKEN', Configuration::getGlobalValue('PUROLATOR_USER_TOKEN')),
            'PUROLATOR_LOG' => Tools::getValue('PUROLATOR_LOG', Configuration::getGlobalValue('PUROLATOR_LOG')),
            'PUROLATOR_POSTCODE' => Tools::getValue('PUROLATOR_POSTCODE', Configuration::getGlobalValue('PUROLATOR_POSTCODE')),
            'PUROLATOR_PACKAGE_TYPE' => Tools::getValue('PUROLATOR_PACKAGE_TYPE', Configuration::getGlobalValue('PUROLATOR_PACKAGE_TYPE')),
            'PUROLATOR_NAME' => Tools::getValue('PUROLATOR_NAME', Configuration::getGlobalValue('PUROLATOR_NAME')),
            'PUROLATOR_COMPANY' => Tools::getValue('PUROLATOR_COMPANY', Configuration::getGlobalValue('PUROLATOR_COMPANY')),
            'PUROLATOR_DEPARTMENT' => Tools::getValue('PUROLATOR_DEPARTMENT', Configuration::getGlobalValue('PUROLATOR_DEPARTMENT')),
            'PUROLATOR_STREET_NAME' => Tools::getValue('PUROLATOR_STREET_NAME', Configuration::getGlobalValue('PUROLATOR_STREET_NAME')),
            'PUROLATOR_STREET_NUMBER' => Tools::getValue('PUROLATOR_STREET_NUMBER', Configuration::getGlobalValue('PUROLATOR_STREET_NUMBER')),
            'PUROLATOR_STREET_TYPE' => Tools::getValue('PUROLATOR_STREET_TYPE', Configuration::getGlobalValue('PUROLATOR_STREET_TYPE')),
            'PUROLATOR_CITY' => Tools::getValue('PUROLATOR_CITY', Configuration::getGlobalValue('PUROLATOR_CITY')),
            'PUROLATOR_PROVINCE' => Tools::getValue('PUROLATOR_PROVINCE', Configuration::getGlobalValue('PUROLATOR_PROVINCE')),
            'PUROLATOR_COUNTRY' => Tools::getValue('PUROLATOR_COUNTRY', Configuration::getGlobalValue('PUROLATOR_COUNTRY')),
            'PUROLATOR_PHONE_AC' => Tools::getValue('PUROLATOR_PHONE_AC', Configuration::getGlobalValue('PUROLATOR_PHONE_AC')),
            'PUROLATOR_PHONE' => Tools::getValue('PUROLATOR_PHONE', Configuration::getGlobalValue('PUROLATOR_PHONE')),
            'PUROLATOR_DOC_TYPE' => Tools::getValue('PUROLATOR_DOC_TYPE', Configuration::getGlobalValue('PUROLATOR_DOC_TYPE')),
            'PUROLATOR_SIGNATURE' => Tools::getValue('PUROLATOR_SIGNATURE', Configuration::getGlobalValue('PUROLATOR_SIGNATURE')),
            'PUROLATOR_EMAIL' => Tools::getValue('PUROLATOR_EMAIL', Configuration::getGlobalValue('PUROLATOR_EMAIL')),
            'PUROLATOR_NOTIFY' => Tools::getValue('PUROLATOR_NOTIFY', Configuration::getGlobalValue('PUROLATOR_NOTIFY')),
            'PUROLATOR_WORTH' => Tools::getValue('PUROLATOR_WORTH', Configuration::getGlobalValue('PUROLATOR_WORTH')),
            'PUROLATOR_PRINTER_TYPE' => Tools::getValue('PUROLATOR_PRINTER_TYPE', Configuration::getGlobalValue('PUROLATOR_PRINTER_TYPE')),
            'PUROLATOR_PICKUP_TYPE' => Tools::getValue('PUROLATOR_PICKUP_TYPE', Configuration::getGlobalValue('PUROLATOR_PICKUP_TYPE')),
            'PUROLATOR_WEIGHT' => Tools::getValue('PUROLATOR_WEIGHT', Configuration::getGlobalValue('PUROLATOR_WEIGHT')),
            'PUROLATOR_MODE_TEST' => Tools::getValue('PUROLATOR_MODE_TEST', Configuration::getGlobalValue('PUROLATOR_MODE_TEST')),
        ));
    }

    public function hookUpdateCarrier($params)
    {
        $old_id = $params['id_carrier'];
        $new_id = $params['carrier']->id;
					   $service_data = Db::getInstance()->getRow('SELECT service,type_id FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE id_carrier=' . (int) $old_id);
        Db::getInstance()->update('purolator_carrier', array('active' => 0), 'id_carrier=' . (int) $old_id);
        Db::getInstance()->insert('purolator_carrier', array('id_carrier' => $new_id, 'service' => $service_data['service'], 'type_id' => $service_data['type_id']));
    }

    public function getOrderShippingCost($params, $shipping_cost)
    {
        if (!$this->active)
            return false;
        $current_service = Db::getInstance()->getValue('SELECT service FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE id_carrier=' . (int) $this->id_carrier);
        if (!$current_service)
            return false;

        if ($this->context->cookie->postcode && $this->context->cookie->id_country && $this->context->cookie->id_state)
            $cookie_state = $this->context->cookie->id_state;
        else
            $cookie_state = $this->context->cookie->pc_dest_state;
        $cookie_zip = $this->context->cookie->postcode ? $this->context->cookie->postcode : $this->context->cookie->pc_dest_zip;
        $cookie_country = $this->context->cookie->id_country ? $this->context->cookie->id_country : $this->context->cookie->pc_dest_country;
        // When placing an order from the backoffice, context->cart is not set
        if (!is_object($this->context->cart))
            $this->context->cart = $params;
        $address = new Address($params->id_address_delivery); // for guest checkout
        if ($this->context->cart->id_address_delivery > 0 && is_object($this->context->customer) && $this->context->customer->logged)
        {
            $address = new Address((int) ($this->context->cart->id_address_delivery));
            if (!Validate::isLoadedObject($address) || !Customer::customerHasAddress((int) ($this->context->cart->id_customer), (int) ($this->context->cart->id_address_delivery)))
            {
                $id_address = Address::getFirstCustomerAddressId($this->context->cart->id_customer, true);
                if ($id_address > 0)
                    $address = new Address((int) ($id_address));
                if (!Validate::isLoadedObject($address) || !Customer::customerHasAddress((int) ($this->context->cart->id_customer), (int) ($this->context->cart->id_address_delivery)))
                    $address = NULL;
            }

            if ($address)
            {
                $dest_zip = $address->postcode;
                $country = new Country($address->id_country);
                $dest_country = $country->iso_code;
                $state = new State($address->id_state);
                $dest_state = $state->iso_code;
            }
            else
                return false;
        }
        elseif (Validate::isLoadedObject($address)) // Guest checkout.
        {
            $dest_zip = $address->postcode;
            $country = new Country($address->id_country);
            $dest_country = $country->iso_code;
            $state = new State($address->id_state);
            $dest_state = $state->iso_code;
        }
        elseif ($cookie_zip)
        {
            $dest_zip = $cookie_zip;
            $country = new Country($cookie_country);
            $dest_country = $country->iso_code;
            $state = new State($cookie_state);
            $dest_state = $state->iso_code;
        }
        // if the order creation is triggered from an exernal site and there is no customer but cart id was passed
        elseif ($this->context->cart->id_address_delivery > 0 && (!is_object($this->context->customer) || !$this->context->customer->logged))
        {
            $address = new Address((int) ($this->context->cart->id_address_delivery));
            if (!Validate::isLoadedObject($address) || !Customer::customerHasAddress((int) ($this->context->cart->id_customer), (int) ($this->context->cart->id_address_delivery)))
            {
                $id_address = Address::getFirstCustomerAddressId($this->context->cart->id_customer, true);
                if ($id_address > 0)
                    $address = new Address((int) ($id_address));
                if (!Validate::isLoadedObject($address) || !Customer::customerHasAddress((int) ($this->context->cart->id_customer), (int) ($this->context->cart->id_address_delivery)))
                    $address = NULL;
            }

            if ($address)
            {
                $dest_zip = $address->postcode;
                $country = new Country($address->id_country);
                $dest_country = $country->iso_code;
                $state = new State($address->id_state);
                $dest_state = $state->iso_code;
            }
            else
                return false;
        }
        else
            return false;

        $api = new PuroLatorAPI(Configuration::getGlobalValue('PUROLATOR_MODE_TEST'), Configuration::getGlobalValue('PUROLATOR_KEY'), Configuration::getGlobalValue('PUROLATOR_PASS'), Configuration::getGlobalValue('PUROLATOR_USER_TOKEN'));

        $request_params = new stdClass();
        $request_params->BillingAccountNumber = Configuration::getGlobalValue('PUROLATOR_BILLING_ACCOUNT');
        $request_params->SenderPostalCode = Configuration::getGlobalValue('PUROLATOR_POSTCODE');
        $request_params->ReceiverAddress = new stdClass();
        $request_params->ReceiverAddress->City = $address->city;
        $request_params->ReceiverAddress->Province = $dest_state;
        $request_params->ReceiverAddress->Country = $dest_country;
        $request_params->ReceiverAddress->PostalCode = $dest_zip;
        $request_params->PackageType = Configuration::getGlobalValue('PUROLATOR_PACKAGE_TYPE');
        $request_params->TotalWeight = new stdClass();

        $peso = (float) Configuration::getGlobalValue('PUROLATOR_WEIGHT');
        if (Combination::isFeatureActive())
            $weight_product_with_attribute = (float) Db::getInstance()->getValue('
				SELECT SUM(IF((p.`weight` + pa.`weight`)>0,(p.`weight` + pa.`weight`),' . $peso . ') * cp.`quantity`)
				FROM `' . _DB_PREFIX_ . 'cart_product` cp
				LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON (cp.`id_product` = p.`id_product`)
				LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute` pa ON (cp.`id_product_attribute` = pa.`id_product_attribute`)
				WHERE (cp.`id_product_attribute` IS NOT NULL AND cp.`id_product_attribute` != 0)
				AND cp.`id_cart` = ' . (int) $this->context->cart->id);
        else
            $weight_product_with_attribute = 0;
        $weight_product_without_attribute = (float) Db::getInstance()->getValue('
			SELECT SUM(IF(p.`weight`>0,p.`weight`,' . $peso . ') * cp.`quantity`) as nb
			FROM `' . _DB_PREFIX_ . 'cart_product` cp
			LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON (cp.`id_product` = p.`id_product`)
			WHERE (cp.`id_product_attribute` IS NULL OR cp.`id_product_attribute` = 0)
			AND cp.`id_cart` = ' . (int) $this->context->cart->id);

        $weight = ceil($weight_product_with_attribute + $weight_product_without_attribute);
        $request_params->TotalWeight->Value = ($weight ? $weight : 1);
        $request_params->TotalWeight->WeightUnit = (in_array(Tools::strtoupper(Tools::substr(Configuration::get('PS_WEIGHT_UNIT'), 0, 2)), array('KG', 'KI')) ? 'kg' : 'lb');

        if (Cache::isStored('purolator-getEstimateCost-' . Tools::jsonEncode($request_params)))
        {
            $shipment_options = Cache::retrieve('purolator-getEstimateCost-' . Tools::jsonEncode($request_params));
            $errors = array();
        }
        else
        {
            $shipment_options = $api->getEstimateCost($request_params, $errors);
            if ($shipment_options)
                Cache::store('purolator-getEstimateCost-' . Tools::jsonEncode($request_params), $shipment_options);
        }
        if ($shipment_options)
            foreach ($shipment_options as $shipment)
                if (str_replace(':', '', $shipment->ServiceID) == $current_service)
                    return Tools::convertPriceFull($shipment->TotalPrice, Currency::getCurrencyInstance(Currency::getIdByIsoCode(self::WEBSERVICE_CURRENCY)), Currency::getCurrencyInstance(Currency::getIdByIsoCode($this->context->currency->id)));

        if (count($errors))
            PuroLatorLog::info("\n\rError WS EstimatingService:\n\r" . implode("\n\r", $errors) . "\n\r");

        return false;
    }

    public function getOrderShippingCostExternal($params)
    {
        $this->getOrderShippingCost($params, 0);
    }

    public function hookDisplayAdminOrder($param)
    {
        $id_order = (int) $param['id_order'];
        $log_url = Context::getContext()->shop->getBaseUrl() . '/modules/purolator/purolator.log';

        include_once(_PS_MODULE_DIR_ . $this->name . '/classes/EnvioPurolator.php');

        if (EnvioPurolator::isPuroLatorCarrierByIdOrder($id_order))
        {
            $error = $result = false;
            $errors = array();
            if (Tools::isSubmit('submitGeneratePuroLator'))
            {
                $request_params = new stdClass();
                $request_params->Shipment = new stdClass();
                $request_params->Shipment->SenderInformation = new stdClass();
                $request_params->Shipment->SenderInformation->Address = new stdClass();
                $request_params->Shipment->SenderInformation->Address->Name = Configuration::getGlobalValue('PUROLATOR_NAME');
                if (Configuration::getGlobalValue('PUROLATOR_COMPANY'))
                    $request_params->Shipment->SenderInformation->Address->Company = Configuration::getGlobalValue('PUROLATOR_COMPANY');
                if (Configuration::getGlobalValue('PUROLATOR_DEPARTMENT'))
                    $request_params->Shipment->SenderInformation->Address->Department = Configuration::getGlobalValue('PUROLATOR_DEPARTMENT');
                $request_params->Shipment->SenderInformation->Address->StreetNumber = Configuration::getGlobalValue('PUROLATOR_STREET_NUMBER');
                $request_params->Shipment->SenderInformation->Address->StreetName = Configuration::getGlobalValue('PUROLATOR_STREET_NAME');
                $request_params->Shipment->SenderInformation->Address->StreetType = Configuration::getGlobalValue('PUROLATOR_STREET_TYPE');
                $request_params->Shipment->SenderInformation->Address->City = Configuration::getGlobalValue('PUROLATOR_CITY');
                $request_params->Shipment->SenderInformation->Address->Province = Tools::strtoupper(Configuration::getGlobalValue('PUROLATOR_PROVINCE'));
                $request_params->Shipment->SenderInformation->Address->PostalCode = Configuration::getGlobalValue('PUROLATOR_POSTCODE');
                $request_params->Shipment->SenderInformation->Address->Country = Configuration::getGlobalValue('PUROLATOR_COUNTRY');
                $request_params->Shipment->SenderInformation->Address->PhoneNumber = new stdClass();
                $request_params->Shipment->SenderInformation->Address->PhoneNumber->AreaCode = Configuration::getGlobalValue('PUROLATOR_PHONE_AC');
                $country = new Country(Country::getByIso(Configuration::getGlobalValue('PUROLATOR_COUNTRY')));
                $request_params->Shipment->SenderInformation->Address->PhoneNumber->CountryCode = $country->call_prefix;
                $request_params->Shipment->SenderInformation->Address->PhoneNumber->Phone = Configuration::getGlobalValue('PUROLATOR_PHONE');

                $order = new Order((int) $id_order);
                $address = new Address($order->id_address_delivery, $order->id_lang);
                $state = new State($address->id_state);
                $request_params->Shipment->ReceiverInformation = new stdClass();
                $request_params->Shipment->ReceiverInformation->Address = new stdClass();
                $request_params->Shipment->ReceiverInformation->Address->Name = Tools::substr($address->firstname . ' ' . $address->lastname, 0, 30);
                if ($address->company)
                    $request_params->Shipment->ReceiverInformation->Address->Company = Tools::substr($address->company, 0, 30);
                $request_params->Shipment->ReceiverInformation->Address->StreetName = Tools::substr($address->address1 . ' ' . $address->address2, 0, 35);
                $request_params->Shipment->ReceiverInformation->Address->City = $address->city;
                $request_params->Shipment->ReceiverInformation->Address->Province = $state->iso_code;
                $request_params->Shipment->ReceiverInformation->Address->PostalCode = $address->postcode;
                $request_params->Shipment->ReceiverInformation->Address->Country = Country::getIsoById($address->id_country);
                if ($address->phone || $address->phone_mobile)
                {
                    $country = new Country($address->id_country);
                    $request_params->Shipment->ReceiverInformation->Address->PhoneNumber = new stdClass();
                    $request_params->Shipment->ReceiverInformation->Address->PhoneNumber->CountryCode = $country->call_prefix;
                    $request_params->Shipment->ReceiverInformation->Address->PhoneNumber->AreaCode = "000";
                    $phone = ($address->phone_mobile ? $address->phone_mobile : $address->phone);
                    $phone = str_replace(array('-', '(', ')', ' ', '.'), '', $phone);
                    $phone = Tools::substr($phone, 0, -7);
                    $phone = str_pad($phone, 7, '0', STR_PAD_LEFT);
                    $request_params->Shipment->ReceiverInformation->Address->PhoneNumber->Phone = $phone;
                }
                if ($address->address2)
                    $request_params->Shipment->ReceiverInformation->Address->StreetAddress2 = Tools::substr($address->address2, 0, 25);
                if ($address->other)
                    $request_params->Shipment->ReceiverInformation->Address->StreetAddress3 = Tools::substr($address->other, 0, 25);

                $request_params->Shipment->PackageInformation = new stdClass();
                $request_params->Shipment->PackageInformation->TotalWeight = new stdClass();
                
                $weight = ceil((float) Tools::getValue('purolator_total_weight'));
                if (!$weight)
                    $weight = ceil((float) Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
		SELECT SUM(IF(product_weight>0,product_weight,' . (float) Configuration::getGlobalValue('PUROLATOR_WEIGHT') . ') * product_quantity)
		FROM ' . _DB_PREFIX_ . 'order_detail WHERE id_order = ' . (int) $id_order));
                $request_params->Shipment->PackageInformation->TotalWeight->Value = ($weight ? $weight : 1);
                $request_params->Shipment->PackageInformation->TotalWeight->WeightUnit = (in_array(Tools::strtoupper(Tools::substr(Configuration::get('PS_WEIGHT_UNIT'), 0, 2)), array('KG', 'KI')) ? 'kg' : 'lb');
                $request_params->Shipment->PackageInformation->TotalPieces = "1";

                //1030AM o 1200 are like 10:30AM o 12:00
                $service_id = Db::getInstance()->getValue('SELECT service FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE id_carrier=' . (int) $order->id_carrier);
                $request_params->Shipment->PackageInformation->ServiceID = str_replace(array('1030AM', '1200'), array('10:30AM', '12:00'), $service_id);

                $request_params->Shipment->PaymentInformation = new stdClass();
                //PaymentType: Sender  Receiver  ThirdParty  CreditCard
                $request_params->Shipment->PaymentInformation->PaymentType = "Sender";
                $request_params->Shipment->PaymentInformation->BillingAccountNumber = Configuration::getGlobalValue('PUROLATOR_BILLING_ACCOUNT');
                $request_params->Shipment->PaymentInformation->RegisteredAccountNumber = Configuration::getGlobalValue('PUROLATOR_REGISTERED_ACCOUNT');

                $request_params->Shipment->PickupInformation = new stdClass();
                //PickupType: DropOff  PreScheduled
                $request_params->Shipment->PickupInformation->PickupType = Configuration::getGlobalValue('PUROLATOR_PICKUP_TYPE');

                $request_params->Shipment->TrackingReferenceInformation = new stdClass();
                $request_params->Shipment->TrackingReferenceInformation->Reference1 = $order->reference;

                //PrinterType: Regular  Thermal
                $request_params->PrinterType = Configuration::getGlobalValue('PUROLATOR_PRINTER_TYPE');

                if (Configuration::getGlobalValue('PUROLATOR_SIGNATURE') || Configuration::getGlobalValue('PUROLATOR_WORTH'))
                {
                    $request_params->OptionsInformation = new stdClass();
                    $request_params->OptionsInformation->Options = new stdClass();
                    $options = array();
                    if (Configuration::getGlobalValue('PUROLATOR_SIGNATURE'))
                    {
                        $option = new stdClass();
                        $option->ID = "ResidentialSignatureDomestic";
                        $option->Value = "true";
                        $options[] = $option;
                    }
                    if (Configuration::getGlobalValue('PUROLATOR_WORTH'))
                    {
                        $option = new stdClass();
                        $option->ID = "DeclaredValue";
                        $option->Value = round($order->getTotalPaid(), 2);
                        $options[] = $option;
                    }
                    $request_params->OptionsInformation->Options->OptionIDValuePair = $options;
                }

                if (Configuration::getGlobalValue('PUROLATOR_EMAIL') || Configuration::getGlobalValue('PUROLATOR_NOTIFY'))
                {
                    $email = (Configuration::getGlobalValue('PUROLATOR_EMAIL') ? Configuration::getGlobalValue('PUROLATOR_EMAIL') : Configuration::get('PS_SHOP_EMAIL'));
                    $request_params->Shipment->ProactiveNotification = new stdClass();
                    $request_params->Shipment->ProactiveNotification->RequestorName = Configuration::get('PS_SHOP_NAME');
                    $request_params->Shipment->ProactiveNotification->RequestorEmail = $email;
                    $request_params->Shipment->ProactiveNotification->Subscriptions = new stdClass();

                    $subcriptions = array();
                    if (Configuration::getGlobalValue('PUROLATOR_EMAIL'))
                    {
                        $subcription = new stdClass();
                        $subcription->Name = Configuration::get('PS_SHOP_NAME');
                        $subcription->Email = $email;
                        $subcription->NotifyWhenExceptionOccurs = "true";
                        $subcription->NotifyWhenDeliveryOccurs = "true";
                        $subcriptions[] = $subcription;
                    }
                    if (Configuration::getGlobalValue('PUROLATOR_NOTIFY'))
                    {
                        $subcription = new stdClass();
                        $subcription->Name = $address->firstname . ' ' . $address->lastname;
                        $subcription->Email = Db::getInstance()->getValue('SELECT email FROM ' . _DB_PREFIX_ . 'customer WHERE id_customer=' . (int) $order->id_customer);
                        $subcription->NotifyWhenExceptionOccurs = "true";
                        $subcription->NotifyWhenDeliveryOccurs = "true";
                        $subcriptions[] = $subcription;
                    }
                    $request_params->Shipment->ProactiveNotification->Subscriptions->Subscription = $subcriptions;
                }

                if (Tools::getValue('international'))
                {
                    $request_params->Shipment->InternationalInformation = new stdClass();
                    $request_params->Shipment->InternationalInformation->DocumentsOnlyIndicator = "false";
                    $request_params->Shipment->InternationalInformation->CustomsInvoiceDocumentIndicator = "false";
                    $request_params->Shipment->InternationalInformation->ImportExportType = Tools::getValue('purolator_import_type');
                    $request_params->Shipment->InternationalInformation->DutyInformation = new stdClass();
                    $request_params->Shipment->InternationalInformation->DutyInformation->BillDutiesToParty = Tools::getValue('purolator_bill_duties');
                    $request_params->Shipment->InternationalInformation->DutyInformation->BusinessRelationship = Tools::getValue('purolator_relationship');
                    $request_params->Shipment->InternationalInformation->DutyInformation->Currency = Tools::getValue('purolator_duty_currency');
                    $harmonized_code = Tools::getValue('purolator_harmonized_code');
                    $order_products = $order->getOrderDetailList();
                    $content_details = array();
                    foreach ($order_products as $prod)
                    {
                        $content = new stdClass();
                        $content->Description = $prod['product_name'];
                        $content->ProductCode = ($prod['product_reference'] ? $prod['product_reference'] : ($prod['product_ean13'] ? $prod['product_ean13'] : $prod['product_upc']));
                        $content->UnitValue = round((float) $prod['original_product_price'], 2);
                        $content->Quantity = (int) $prod['product_quantity'];
                        if ($harmonized_code)
                            $content->HarmonizedCode = $harmonized_code;
                        $content_details[] = $content;
                    }
                    $request_params->Shipment->InternationalInformation->ContentDetails = new stdClass();
                    $request_params->Shipment->InternationalInformation->ContentDetails->ContentDetail = $content_details;
                }

                $api = new PuroLatorAPI(Configuration::getGlobalValue('PUROLATOR_MODE_TEST'), Configuration::getGlobalValue('PUROLATOR_KEY'), Configuration::getGlobalValue('PUROLATOR_PASS'), Configuration::getGlobalValue('PUROLATOR_USER_TOKEN'));
                $result = $api->generateShipment($request_params, $errors);
                if ($result)
                {
                    $envio = new EnvioPurolator();
                    $envio->id_order = $id_order;
                    $envio->pin = $result;
                    $envio->add();

                    Db::getInstance()->update('orders', array('shipping_number' => $result), 'id_order=' . $id_order);
                }
                else
                {
                    $error = $this->l('Errors creating shipment. Check log file for more information.') . ' ' . $this->l('You can check log file at:') . ' <a target="_blank" href="' . $log_url . '">' . $log_url . '</a>';
                    if (count($errors))
                        PuroLatorLog::info("\n\rError WS CreateShipment:\n\r" . implode("\n\r", $errors) . "\n\r");
                }
            }
            elseif (Tools::isSubmit('submitGetDeliveredProof'))
            {
                $id_purolator = EnvioPurolator::getIdPuroLatorByIdOrder($id_order);
                $envio = new EnvioPurolator($id_purolator);
                $request_params = new stdClass();
                $request_params->PIN = new stdClass();
                $request_params->PIN->Value = $envio->pin;

                $api = new PuroLatorAPI(Configuration::getGlobalValue('PUROLATOR_MODE_TEST'), Configuration::getGlobalValue('PUROLATOR_KEY'), Configuration::getGlobalValue('PUROLATOR_PASS'), Configuration::getGlobalValue('PUROLATOR_USER_TOKEN'));
                $result = $api->getDeliveredProof($request_params, $errors);
                if ($result)
                {
                    switch ($result->ScanDetails->SignatureImageFormat)
                    {
                        case 'Bitmap':
                            $ext = '.bmp';
                            break;
                        case 'OriginalUncompressed':
                            $ext = '.jpg';
                            break;
                        default:
                            $ext = '.gif';
                            break;
                    }
                    file_put_contents(dirname(__FILE__) . '/delivered/' . $id_order . $ext, base64_decode($result->ScanDetails->SignatureImage));

                    $envio->status = 'delivered';
                    $envio->date_delivered = $result->ScanDate . ' ' . Tools::substr($result->ScanTime, 0, 2) . ':' . Tools::substr($result->ScanTime, 2, 2) . ':00';
                    $envio->delivered_file = $id_order . $ext;
                    $envio->update();
                }
                else
                {
                    $error = $this->l('Errors getting shipment delivered proof. Check log file for more information.') . ' ' . $this->l('You can check log file at:') . ' <a target="_blank" href="' . $log_url . '">' . $log_url . '</a>';
                    if (count($errors))
                        PuroLatorLog::info("\n\rError WS GetDeliveryDetails:\n\r" . implode("\n\r", $errors) . "\n\r");
                }
            }
            elseif (Tools::isSubmit('submitCancelPuroLator'))
            {
                $id_purolator = EnvioPurolator::getIdPuroLatorByIdOrder($id_order);
                $envio = new EnvioPurolator($id_purolator);
                $request_params = new stdClass();
                $request_params->PIN = new stdClass();
                $request_params->PIN->Value = $envio->pin;

                $api = new PuroLatorAPI(Configuration::getGlobalValue('PUROLATOR_MODE_TEST'), Configuration::getGlobalValue('PUROLATOR_KEY'), Configuration::getGlobalValue('PUROLATOR_PASS'), Configuration::getGlobalValue('PUROLATOR_USER_TOKEN'));
                $result = $api->cancelShipment($request_params, $errors);
                if ($result)
                {
                    $envio->status = 'canceled';
                    $envio->update();

                    Db::getInstance()->update('orders', array('shipping_number' => ''), 'id_order=' . $id_order);
                }
                else
                {
                    $error = $this->l('Errors canceling shipment. Check log file for more information.') . ' ' . $this->l('You can check log file at:') . ' <a target="_blank" href="' . $log_url . '">' . $log_url . '</a>';
                    if (count($errors))
                        PuroLatorLog::info("\n\rError WS VoidShipment:\n\r" . implode("\n\r", $errors) . "\n\r");
                }
            }

            $status = EnvioPurolator::getPuroLatorStatusByIdOrder($id_order);
            echo $this->renderOrderForm($id_order, $status, $error);
        }
								
    }

    private function renderOrderForm($id_order, $type = false, $error = false)
    {
        $log_url = Context::getContext()->shop->getBaseUrl() . '/modules/purolator/purolator.log';
        /* 'generated', 'consolidated', 'canceled', 'delivered' */
        switch ($type)
        {
            case 'generated':
                {
                    $id_purolator = EnvioPurolator::getIdPuroLatorByIdOrder($id_order);
                    $submit_action = 'submitCancelPuroLator';
                    $envio = new EnvioPurolator($id_purolator);
                    $fields_value = array(
                        'pin' => $envio->pin,
                        'date_add' => Tools::displayDate($envio->date_add)
                    );
                    $url_pdf = $envio->url;
                    if (!$url_pdf)
                    {
                        $errors = array();
                        $request_params = new stdClass();
                        $request_params->DocumentCriterium = new stdClass();
                        $request_params->DocumentCriterium->DocumentCriteria = new stdClass();
                        $request_params->DocumentCriterium->DocumentCriteria->PIN = new stdClass();
                        $request_params->DocumentCriterium->DocumentCriteria->PIN->Value = $envio->pin;
                        $request_params->DocumentCriterium->DocumentCriteria->DocumentTypes = new stdClass();
                        $request_params->DocumentCriterium->DocumentCriteria->DocumentTypes->DocumentType = Configuration::getGlobalValue('PUROLATOR_DOC_TYPE');
                        $api = new PuroLatorAPI(Configuration::getGlobalValue('PUROLATOR_MODE_TEST'), Configuration::getGlobalValue('PUROLATOR_KEY'), Configuration::getGlobalValue('PUROLATOR_PASS'), Configuration::getGlobalValue('PUROLATOR_USER_TOKEN'));
                        $result = $api->getDocuments($request_params, $errors);
                        if ($result)
                        {
                            $envio->url = $result;
                            $envio->update();

                            $url_pdf = $result;
                        }
                        else
                        {
                            $error = $this->l('Errors getting shipment document. Check log file for more information.') . ' ' . $this->l('You can check log file at:') . ' <a target="_blank" href="' . $log_url . '">' . $log_url . '</a>';
                            if (count($errors))
                                PuroLatorLog::info("\n\rError WS GetDocuments:\n\r" . implode("\n\r", $errors) . "\n\r");
                        }
                    }
                    $fields_form = array(
                        'form' => array(
                            'legend' => array(
                                'title' => $this->l('PuroLator Shipping'),
                                'image' => '../modules/' . $this->name . '/logo.png'
                            ),
                            'error' => $error,
                            'success' => (Tools::isSubmit('submitGeneratePuroLator') && !$error ? $this->l('Shipment created successfully.') : false),
                            'input' => array(
                                array(
                                    'type' => 'text',
                                    'label' => $this->l('Shipment PIN Number'),
                                    'name' => 'pin',
                                    'readonly' => true
                                ),
                                array(
                                    'type' => 'text',
                                    'label' => $this->l('Shipment Date'),
                                    'name' => 'date_add',
                                    'readonly' => true
                                ),
                            ),
                        )
                    );
                    if (Tools::isSubmit('submitCancelPuroLator') || !$error)
                        $fields_form['form']['buttons'] = array(
                            'etiqueta' => array(
                                'name' => 'submitGetLabel',
                                'title' => $this->l('Label PDF'),
                                'class' => 'pull-right',
                                'icon' => 'icon-print',
                                'js' => 'window.open(\'' . $url_pdf . '\');'
                            ),
                            'enviado' => array(
                                'name' => 'submitGetDeliveredProof',
                                'title' => $this->l('Delivered Proof'),
                                'class' => 'pull-right',
                                'icon' => 'icon-image',
                                'type' => 'submit'
                            )
                        );
                    if (Tools::substr($envio->date_add, 0, 10) == date('Y-m-d'))
                        $fields_form['form']['submit'] = array(
                            'title' => $this->l('Cancel Shipment'),
                            'icon' => 'icon-minus-sign'
                        );
                }
                break;
            case 'delivered':
                {
                    $id_purolator = EnvioPurolator::getIdPuroLatorByIdOrder($id_order);
                    $submit_action = '';
                    $envio = new EnvioPurolator($id_purolator);
                    $fields_value = array(
                        'pin' => $envio->pin,
                        'date_delivered' => Tools::displayDate($envio->date_delivered)
                    );
                    $url_proof = Context::getContext()->shop->getBaseUrl() . '/modules/purolator/delivered/' . $envio->delivered_file;
                    $this->context->smarty->assign(array('url_proof' => $url_proof));
                    $fields_form = array(
                        'form' => array(
                            'legend' => array(
                                'title' => $this->l('PuroLator Shipping'),
                                'image' => '../modules/' . $this->name . '/logo.png'
                            ),
                            'input' => array(
                                array(
                                    'type' => 'text',
                                    'label' => $this->l('Shipment PIN Number'),
                                    'name' => 'pin',
                                    'readonly' => true
                                ),
                                array(
                                    'type' => 'text',
                                    'label' => $this->l('Delivered Date'),
                                    'name' => 'date_delivered',
                                    'readonly' => true
                                ),
                                array(
                                    'type' => 'html',
                                    'name' => 'delivered_file',
                                    'html_content' => $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'purolator/views/templates/admin/delivery_image.tpl')
                                ),
                            ),
                        )
                    );
                }
                break;
            default:
                {
                    $fields_form = array(
                        'form' => array(
                            'legend' => array(
                                'title' => $this->l('PuroLator Shipping'),
                                'image' => '../modules/' . $this->name . '/logo.png'
                            ),
                            'error' => $error,
                            'success' => ($type == 'canceled' ? $this->l('Shipment canceled successfully.') : false),
                            'input' => array(
                                array(
                                    'type' => 'text',
                                    'label' => $this->l('Purolator Service'),
                                    'name' => 'service',
                                    'readonly' => true
                                ),
                                array(
                                    'type' => 'text',
                                    'label' => $this->l('Order Total Weight'),
                                    'name' => 'purolator_total_weight',
                                    'prefix' => Configuration::getGlobalValue('PS_WEIGHT_UNIT'),
                                    'hint' => $this->l('Total order weight. If not set default weight calculation will be used.')
                                ),
                            ),
                            'submit' => array(
                                'title' => $this->l('Generate Shipment'),
                                'icon' => 'icon-truck'
                            )
                        ),
                    );
                    $submit_action = 'submitGeneratePuroLator';
                    $order = new Order($id_order);
                    $address = Address::getCountryAndState($order->id_address_delivery);
                    if ($address['id_country'] != 4)//ID Canada
                    {
                        $fields_form['form']['input'] = array_merge($fields_form['form']['input'], array(
                            array(
                                'type' => 'hidden',
                                'name' => 'international'
                            ),
                            array(
                                'type' => 'select',
                                'label' => $this->l('Import/Export Type'),
                                'name' => 'purolator_import_type',
                                'options' => array(
                                    'query' => array(
                                        array('id' => 'Permanent', 'name' => $this->l('Permanent')),
                                        array('id' => 'Temporary', 'name' => $this->l('Temporary')),
                                        array('id' => 'Repair', 'name' => $this->l('Repair')),
                                        array('id' => 'Return', 'name' => $this->l('Return'))
                                    ),
                                    'id' => 'id',
                                    'name' => 'name'
                                ),
                                'required' => true
                            ),
                            array(
                                'type' => 'text',
                                'label' => $this->l('Products Harmonized Code'),
                                'name' => 'purolator_harmonized_code'
                            ),
                            array(
                                'type' => 'select',
                                'label' => $this->l('Bill Duties To Party'),
                                'name' => 'purolator_bill_duties',
                                'options' => array(
                                    'query' => array(
                                        array('id' => 'Sender', 'name' => $this->l('Sender')),
                                        array('id' => 'Receiver', 'name' => $this->l('Receiver')),
                                        array('id' => 'Buyer', 'name' => $this->l('Buyer'))
                                    ),
                                    'id' => 'id',
                                    'name' => 'name'
                                ),
                                'required' => true
                            ),
                            array(
                                'type' => 'select',
                                'label' => $this->l('Business Relationship'),
                                'name' => 'purolator_relationship',
                                'options' => array(
                                    'query' => array(
                                        array('id' => 'Related', 'name' => $this->l('Related')),
                                        array('id' => 'NotRelated', 'name' => $this->l('Not Related'))
                                    ),
                                    'id' => 'id',
                                    'name' => 'name'
                                ),
                                'required' => true
                            ),
                            array(
                                'type' => 'select',
                                'label' => $this->l('Duty Currency'),
                                'name' => 'purolator_duty_currency',
                                'options' => array(
                                    'query' => array(
                                        array('id' => 'CAD', 'name' => $this->l('Canadian Dollar')),
                                        array('id' => 'USD', 'name' => $this->l('U.S. Dollar'))
                                    ),
                                    'id' => 'id',
                                    'name' => 'name'
                                ),
                                'required' => true
                            ),
                        ));
                    }
                    $service_id = Db::getInstance()->getValue('SELECT service FROM ' . _DB_PREFIX_ . 'purolator_carrier WHERE id_carrier=' . (int) $order->id_carrier);
                    $fields_value = array(
                        'service' => ($service_id ? $this->services[$service_id] : false),
                        'purolator_import_type' => false,
                        'purolator_harmonized_code' => false,
                        'purolator_bill_duties' => false,
                        'purolator_relationship' => false,
                        'purolator_duty_currency' => false,
                        'international' => true,
                        'purolator_total_weight' => 0
                    );
                }
                break;
        }

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = $submit_action;
        $helper->tpl_vars = array(
            'fields_value' => $fields_value,
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

}
