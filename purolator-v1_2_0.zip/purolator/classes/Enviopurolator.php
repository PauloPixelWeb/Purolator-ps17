<?php
/**
 * 2010-2018 PixelWeb
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Software License Agreement that you can get at:
 * http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 *
 *  @author    PixelWeb <paulo@lievant.com>
 *  @copyright 2010-2018 Addons-Modules.com - Pixelweb.com.mx
 *  @license   http://addons-modules.com/store/en/content/3-terms-and-conditions-of-use
 */




class EnvioPurolator extends ObjectModel
{

    public $id_order;
    public $status;
    public $pin;
    public $url;
    public $date_delivered;
    public $delivered_file;
    public $date_upd;
    public $date_add;
    public static $definition = array(
        'table' => 'purolator_envio',
        'primary' => 'id_purolator_envio',
        'fields' => array(
            'id_order' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'status' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'values' => array('generated', 'consolidated', 'canceled', 'delivered'), 'default' => 'generated'),
            'pin' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'max' => 20),
            'url' => array('type' => self::TYPE_STRING, 'validate' => 'isUrl'),
            'delivered_file' => array('type' => self::TYPE_STRING, 'validate' => 'isFileName'),
            'date_delivered' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat'),
            'date_add' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'copy_post' => false),
            'date_upd' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'copy_post' => false)
        )
    );

    public static function getIdPuroLatorByIdOrder($id_order)
    {
        return Db::getInstance()->getValue('SELECT id_purolator_envio 
                                            FROM ' . _DB_PREFIX_ . 'purolator_envio 
                                            WHERE status != "canceled" AND id_order=' . (int) $id_order . '
                                            ORDER BY id_purolator_envio DESC');
    }

    public static function getPuroLatorStatusByIdOrder($id_order)
    {
        return Db::getInstance()->getValue('SELECT status 
                                            FROM ' . _DB_PREFIX_ . 'purolator_envio 
                                            WHERE id_order=' . (int) $id_order . '
                                            ORDER BY id_purolator_envio DESC');
    }

    public static function getPuroLatorPDFByIdOrder($id_order)
    {
        return Db::getInstance()->getValue('SELECT url
                                            FROM ' . _DB_PREFIX_ . 'purolator_envio 
                                            WHERE id_order=' . (int) $id_order);
    }

    public static function getPuroLatorDeliveryFileByIdOrder($id_order)
    {
        return Db::getInstance()->getValue('SELECT delivered_file 
                                            FROM ' . _DB_PREFIX_ . 'purolator_envio 
                                            WHERE id_order=' . (int) $id_order . '
                                            ORDER BY id_purolator_envio DESC');
    }

    public static function isPuroLatorCarrierByIdOrder($id_order)
    {
        return (bool) Db::getInstance()->getValue('SELECT *
                FROM `' . _DB_PREFIX_ . 'orders` o
                INNER JOIN `' . _DB_PREFIX_ . 'carrier` ca ON (o.`id_carrier` = ca.`id_carrier` AND ca.`external_module_name` = "purolator")
                WHERE o.`id_order`=' . (int) $id_order);
    }

}
